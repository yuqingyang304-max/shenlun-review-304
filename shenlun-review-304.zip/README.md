# 申论批改304

根据你提供的申论模板及手写答卷，输出小题红线版 PDF 和无新增红线版 PDF。先提供模板 PDF 和按作答顺序排列的答卷照片。

- 支持 Agent Skills 的工具可导入整个 [skills/shenlun-review-304](skills/shenlun-review-304/) 文件夹，再调用 `$shenlun-review-304` 或输入「用申论批改304批改附件」。
- 只支持读取 GitHub 文件的工具，可让它按 [SKILL.md](skills/shenlun-review-304/SKILL.md) 执行，并允许它读取同目录的引用文件。出 PDF 需要该工具能够处理附件、图片及 PDF。
- 私有仓库需要目标软件登录有仓库读取权限的 GitHub 账号，或由已授权的连接器访问。

仓库随附批改规则和校验脚本。模板和答卷在实际使用时提供。
