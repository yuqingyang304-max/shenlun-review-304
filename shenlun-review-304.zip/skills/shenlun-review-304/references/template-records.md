# 模板与学生核对记录

模板采分点JSON包含template_id及questions；每题id、type（small/essay）、stem、max_score。小题items包含唯一id、原语段text、points、source_page、bbox、mark_type与verification。作文另存bands原文；配分或分档歧义写conflicts，能定位题目时加question_id，特定分数边界加affected_scores。所有坐标注明原点和单位。

学生内部记录采用：

```json
{
  "template_id": "第四套",
  "questions": [{
    "id": "1",
    "matches": [{
      "point_id": "1-1",
      "verdict": "matched",
      "evidence": "学生实际写出的原话",
      "student_location": {"page": 1, "bbox": [10, 20, 80, 35]}
    }]
  }]
}
```

verdict取matched/not_matched/uncertain，每个采分点必须有明确决策且不重复。matched必须有实际学生原话及Image worker定位，不得用答案文本冒充。结构/逻辑项的evidence写实际结构观察，不虚构可划线句子；mark_type为structure/logic或其_score形式，不强制student_location。

作文记录为id、score及grade_reason，不套小题matches。脚本不决定同义是否完整，不从字符串自动推断语义；先人工核对再运行校验。没有新学生时不能生成虚假批改记录。

运行 `python scripts/template_checks.py 模板采分点.json --matches 学生核对.json`。无--matches时只验模板。存在冲突时返回待核，不自动补足或缩放分数；作文某边界有歧义不阻塞其他小题，实际遇边界才影响该作文结果。真实学生红线坐标在裁剪、粘贴、缩放后按新画布变换，内部记录同时保留原学生页号，不能直接把模板标准答案坐标画在学生图上。
