"""Small regression cases for scoring invariants, not semantic grading."""
from copy import deepcopy
from template_checks import check_template,check_matches

T={'template_id':'test','questions':[{'id':'1','type':'small','max_score':3,'items':[{'id':'1-a','text':'允许科研失败','points':1,'verification':'confirmed','mark_type':'red_underline'},{'id':'1-b','text':'归纳合理、层次分明','points':2,'verification':'confirmed','mark_type':'structure'}]}]}
R={'template_id':'test','questions':[{'id':'1','matches':[{'point_id':'1-a','verdict':'matched','evidence':'容许试错','student_location':{'page':1,'bbox':[10,20,70,40]}},{'point_id':'1-b','verdict':'matched','evidence':'三个问题分别与其解决办法对应，层次清楚'}]}]}
assert check_template(T)['ready_for_final_scores']
assert check_matches(T,R)['scores']['1']['confirmed_points']==3
duplicate=deepcopy(R);duplicate['questions'][0]['matches'].append(deepcopy(R['questions'][0]['matches'][0]))
assert not check_matches(T,duplicate)['valid']
incomplete=deepcopy(R);incomplete['questions'][0]['matches'].pop()
assert not check_matches(T,incomplete)['valid']
wrong=deepcopy(T);wrong['questions'][0]['max_score']=5
assert not check_template(wrong)['ready_for_final_scores']
assert check_matches(wrong,R)['scores']['1']['confirmed_points']==3
unknown=deepcopy(T);unknown['questions'][0]['items'][0]['points']=None
assert not check_template(unknown)['ready_for_final_scores']
assert not check_matches(unknown,R)['final']
assert check_matches(unknown,R)['scores']['1']['confirmed_points']==2
not_matched=deepcopy(R);not_matched['questions'][0]['matches'][0]={'point_id':'1-a','verdict':'not_matched'}
assert check_matches(T,not_matched)['scores']['1']['confirmed_points']==2
bad_evidence=deepcopy(R);bad_evidence['questions'][0]['matches'][0]['evidence']=''
assert not check_matches(T,bad_evidence)['valid']
scoped=deepcopy(T)
scoped['questions'].append({'id':'5','type':'essay','max_score':35,'bands':[{'label':'二类','min':15,'max':26}]})
scoped['conflicts']=[{'question_id':'5','affected_scores':[5,15,26],'detail':'original boundaries overlap'}]
assert not check_template(scoped)['ready_for_final_scores']
assert check_matches(scoped,R)['final']
ordinary={'template_id':'test','questions':[{'id':'5','score':22,'grade_reason':'按模板二类，论证一般'}]}
assert check_matches(scoped,ordinary)['final']
boundary=deepcopy(ordinary);boundary['questions'][0]['score']=26
assert not check_matches(scoped,boundary)['final']
print('11 scenarios passed, including essay-boundary warnings scoped to affected questions and scores.')
