"""Check template points and human-reviewed matches; never infer semantic matches."""
from pathlib import Path
import argparse,json,math

def check_template(data):
 errors=[];conflicts=[];seen=set()
 if not data.get('template_id'):errors.append('missing template_id')
 for q in data.get('questions',[]):
  qid=str(q.get('id',''))
  if not qid or qid in seen:errors.append(f'duplicate/empty question id: {qid}')
  seen.add(qid)
  if q.get('type')=='essay':
   if not q.get('bands'):conflicts.append(f'{qid}: no essay bands')
   continue
  if q.get('type')!='small':errors.append(f'{qid}: unknown question type')
  ids=set();total=0;unknown=False
  for p in q.get('items',[]):
   pid=str(p.get('id',''))
   if not pid or pid in ids:errors.append(f'{qid}: duplicate/empty point id: {pid}')
   ids.add(pid)
   value=p.get('points')
   if value is None:unknown=True;conflicts.append(f'{pid}: unresolved points')
   elif isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or value<=0:errors.append(f'{pid}: invalid points')
   else:total+=value
   if not p.get('text'):errors.append(f'{pid}: missing source text')
   if p.get('verification')!='confirmed':conflicts.append(f'{pid}: source not confirmed')
  maximum=q.get('max_score')
  if not isinstance(maximum,(int,float)) or isinstance(maximum,bool) or maximum<=0:errors.append(f'{qid}: invalid maximum')
  elif not unknown and abs(total-maximum)>1e-6:conflicts.append(f'{qid}: listed {total:g}, maximum {maximum:g}; do not normalize')
 if not seen:errors.append('no questions')
 for c in data.get('conflicts',[]):conflicts.append(c)
 return {'valid':not errors,'ready_for_final_scores':not errors and not conflicts,'errors':errors,'conflicts':conflicts}

def conflict_applies(conflict,question_records,known_questions):
 if isinstance(conflict,dict):
  qid=conflict.get('question_id')
  if qid is None:return True
  selected=[q for q in question_records if str(q.get('id',''))==str(qid)]
  if not selected:return False
  affected=conflict.get('affected_scores')
  if affected is not None:return any(q.get('score') is None or q['score'] in affected for q in selected)
  return True
 prefix=str(conflict).split(':',1)[0]
 if prefix in known_questions:return prefix in {str(q.get('id','')) for q in question_records}
 return True

def check_matches(template,record):
 result=check_template(template);errors=list(result['errors']);totals={}
 known_questions={str(q['id']) for q in template.get('questions',[])}
 warnings=[c for c in result['conflicts'] if conflict_applies(c,record.get('questions',[]),known_questions)]
 if record.get('template_id')!=template.get('template_id'):errors.append('template_id mismatch')
 questions={str(q['id']):q for q in template.get('questions',[])};seen=set()
 for qr in record.get('questions',[]):
  qid=str(qr.get('id',''))
  if qid in seen:errors.append(f'{qid}: repeated question record');continue
  seen.add(qid)
  if qid not in questions:errors.append(f'{qid}: unknown question');continue
  q=questions[qid]
  if q.get('type')=='essay':
   score=qr.get('score')
   if not isinstance(score,(int,float)) or isinstance(score,bool) or not 0<=score<=q['max_score']:errors.append(f'{qid}: invalid essay score')
   elif not qr.get('grade_reason'):errors.append(f'{qid}: essay needs grade_reason')
   else:totals[qid]=score
   continue
  points={str(p['id']):p for p in q.get('items',[])};used=set();total=0;pending=False
  for m in qr.get('matches',[]):
   pid=str(m.get('point_id',''))
   if pid in used:errors.append(f'{qid}: duplicate match {pid}');continue
   used.add(pid)
   if pid not in points:errors.append(f'{qid}: unknown point {pid}');continue
   verdict=m.get('verdict')
   if verdict not in ['matched','not_matched','uncertain']:errors.append(f'{pid}: invalid verdict');continue
   if verdict=='uncertain':pending=True;warnings.append(f'{pid}: undecided match')
   if verdict!='matched':continue
   if not m.get('evidence','').strip():errors.append(f'{pid}: matched point needs exact student evidence')
   p=points[pid]
   if p.get('mark_type') not in ['structure','structure_score','logic','logic_score']:
    loc=m.get('student_location',{});box=loc.get('bbox',[])
    if not isinstance(loc.get('page'),int) or loc['page']<1 or len(box)!=4 or not all(isinstance(x,(float,int)) for x in box) or box[0]>=box[2] or box[1]>=box[3]:errors.append(f'{pid}: text match needs student page and positive bbox')
   if p.get('points') is None:pending=True;warnings.append(f'{pid}: matched unresolved point')
   elif p.get('verification')!='confirmed':pending=True;warnings.append(f'{pid}: source point unconfirmed')
   else:total+=p['points']
  missing=set(points)-used
  if missing:errors.append(f'{qid}: missing point decisions {sorted(missing)}')
  totals[qid]={'confirmed_points':total,'pending':pending}
 if not seen:errors.append('no question records')
 return {'valid':not errors,'final':not errors and not warnings,'errors':errors,'warnings':warnings,'scores':totals}

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('template',type=Path);ap.add_argument('--matches',type=Path)
 args=ap.parse_args();t=json.loads(args.template.read_text(encoding='utf-8-sig'))
 result=check_matches(t,json.loads(args.matches.read_text(encoding='utf-8-sig'))) if args.matches else check_template(t)
 print(json.dumps(result,ensure_ascii=False,indent=2))
 return 0 if result.get('final',result.get('ready_for_final_scores',False)) else 2
if __name__=='__main__':raise SystemExit(main())
